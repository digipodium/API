const express = require("express");
const cors = require("cors");
const path = require('path');
const history = require('express-history-api-fallback');

const userRouter = require("./routers/userRouter");

const app = express();

require("dotenv").config();
const root = path.join(__dirname, 'public');

// middlewares
app.use(
  cors({
    origin: "http://localhost:3000",
  })
);
app.use(express.json());
app.use(express.static("./uploads"));
app.use(express.static("./public"));
app.use("/user", userRouter);

app.use(history('index.html', { root }));

app.get("/", (req, res) => {
  res.send("Working Fine!!");
});

app.listen(process.env.PORT, () => {
  console.info("Server Started>>");
});
