
const api_config = {
    PORT : 5000
}

module.exports = api_config;